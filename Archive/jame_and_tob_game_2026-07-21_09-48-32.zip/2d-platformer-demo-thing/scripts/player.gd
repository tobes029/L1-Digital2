extends CharacterBody2D


const SPEED = 10000.0
const JUMP_VELOCITY = -400.0



@export var speed: float = 200.0

#walking isbasicaly just foating really
func _physics_process(delta: float) -> void:
	# Get input vectors (returns 0 to 1 based on strength)
	var input_vector = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	
	# Move the character
	velocity = input_vector * speed
	
	# Use move_and_slide to apply movement and handle collisions
	move_and_slide()
